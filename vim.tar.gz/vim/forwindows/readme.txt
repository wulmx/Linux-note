copy 2 exe file to C:\Windows\System32

 vim /etc/vimrc
 ls /usr/share/vim/vim81
 cp vim/.vim/* /usr/share/vim/vim81/
